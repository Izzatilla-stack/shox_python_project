Pong
====

Pong, classic arcade game.

.. literalinclude:: ../freegames/pong.py
