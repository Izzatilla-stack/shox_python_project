Paint
=====

Paint, for drawing shapes.

.. literalinclude:: ../freegames/paint.py
