Tiles
=====

Tiles, number swapping game.

.. literalinclude:: ../freegames/tiles.py
