Life
====

Game of Life simulation.

.. literalinclude:: ../freegames/life.py
