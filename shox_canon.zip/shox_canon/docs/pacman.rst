Pacman
======

Pacman, classic arcade game.

.. literalinclude:: ../freegames/pacman.py
