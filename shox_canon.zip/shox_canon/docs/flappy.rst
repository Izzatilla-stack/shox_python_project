Flappy
======

Flappy, game inspired by Flappy Bird.

.. literalinclude:: ../freegames/flappy.py
