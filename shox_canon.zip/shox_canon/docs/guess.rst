Guess
=====

Guess a number within a range.

.. literalinclude:: ../freegames/guess.py
